create extension if not exists pgcrypto;

create table if not exists public.users(id uuid primary key default gen_random_uuid(),telegram_id text unique not null,first_name text not null default '',last_name text not null default '',username text,active_role text not null default 'worker',banned boolean not null default false,ban_until timestamptz,ban_reason text,referral_locked boolean not null default false,is_admin boolean not null default false,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create table if not exists public.wallets(user_id uuid primary key references public.users(id) on delete cascade,available numeric(14,2) not null default 0,reserved numeric(14,2) not null default 0,lifetime_earned numeric(14,2) not null default 0,lifetime_spent numeric(14,2) not null default 0,updated_at timestamptz not null default now());
create table if not exists public.categories(id uuid primary key default gen_random_uuid(),name text unique not null,active boolean not null default true,created_at timestamptz not null default now());
create table if not exists public.tasks(id uuid primary key default gen_random_uuid(),client_id uuid not null references public.users(id),category text not null,title text not null,description text not null,requirements text not null default '',budget numeric(14,2) not null,platform_fee numeric(14,2) not null default 0,worker_reward numeric(14,2) not null,deadline_at timestamptz not null,status text not null default 'open',assigned_worker_id uuid references public.users(id),assigned_at timestamptz,submitted_at timestamptz,completed_at timestamptz,revision_count integer not null default 0,revision_limit integer not null default 2,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create table if not exists public.task_files(id uuid primary key default gen_random_uuid(),task_id uuid not null references public.tasks(id) on delete cascade,file_path text,file_url text,file_name text,mime_type text,size_bytes bigint,created_at timestamptz not null default now());
create table if not exists public.submissions(id uuid primary key default gen_random_uuid(),task_id uuid not null unique references public.tasks(id) on delete cascade,worker_id uuid not null references public.users(id),content text not null default '',created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create table if not exists public.submission_files(id uuid primary key default gen_random_uuid(),submission_id uuid not null references public.submissions(id) on delete cascade,file_path text not null,file_name text,mime_type text,size_bytes bigint);
create table if not exists public.revisions(id uuid primary key default gen_random_uuid(),task_id uuid not null references public.tasks(id) on delete cascade,client_id uuid not null references public.users(id),reason text not null,created_at timestamptz not null default now());
create table if not exists public.disputes(id uuid primary key default gen_random_uuid(),task_id uuid not null references public.tasks(id) on delete cascade,opened_by uuid not null references public.users(id),reason text not null,evidence text,status text not null default 'open',resolution text,created_at timestamptz not null default now(),resolved_at timestamptz);
create table if not exists public.ledger_entries(id uuid primary key default gen_random_uuid(),user_id uuid references public.users(id),task_id uuid references public.tasks(id),type text not null,amount numeric(14,2) not null,currency text not null default 'ETB',reference_id text,description text,created_at timestamptz not null default now());
create table if not exists public.deposits(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.users(id),amount numeric(14,2) not null,method text not null,reference text,proof_url text,status text not null default 'pending',reviewed_by uuid references public.users(id),reviewed_at timestamptz,created_at timestamptz not null default now());
create table if not exists public.withdrawals(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.users(id),amount numeric(14,2) not null,fee numeric(14,2) not null default 0,method text not null,account_number text not null,account_name text not null,status text not null default 'pending',rejection_reason text,processed_by uuid references public.users(id),processed_at timestamptz,created_at timestamptz not null default now());
create table if not exists public.referrals(id uuid primary key default gen_random_uuid(),referrer_id uuid not null references public.users(id),referred_id uuid not null unique references public.users(id),created_at timestamptz not null default now(),check(referrer_id<>referred_id));
create table if not exists public.referral_rewards(id uuid primary key default gen_random_uuid(),referral_id uuid not null references public.referrals(id),task_id uuid not null unique references public.tasks(id),referrer_id uuid not null references public.users(id),referred_worker_id uuid not null references public.users(id),amount numeric(14,2) not null,created_at timestamptz not null default now());
create table if not exists public.notifications(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.users(id) on delete cascade,title text not null,body text not null,type text not null,read_at timestamptz,created_at timestamptz not null default now());
create table if not exists public.bans(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.users(id),type text not null,reason text not null,evidence text,starts_at timestamptz not null default now(),ends_at timestamptz,created_by uuid references public.users(id),appeal_status text not null default 'none',created_at timestamptz not null default now());
create table if not exists public.appeals(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.users(id),ban_id uuid references public.bans(id),reason text not null,status text not null default 'pending',admin_response text,created_at timestamptz not null default now(),reviewed_at timestamptz);
create table if not exists public.audit_logs(id uuid primary key default gen_random_uuid(),actor_id uuid references public.users(id),action text not null,entity_type text,entity_id text,details jsonb,created_at timestamptz not null default now());
create table if not exists public.platform_settings(key text primary key,value text not null,updated_at timestamptz not null default now());
create table if not exists public.ad_rewards(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.users(id) on delete cascade,amount numeric(14,2) not null default 1,provider text not null default 'adsgram',event_id text unique not null,created_at timestamptz not null default now());

insert into public.categories(name) values('graphic_design'),('logo_design'),('video_editing'),('photo_editing'),('writing'),('translation'),('data_entry'),('voice_over'),('social_media'),('programming'),('website_development'),('ai_services'),('marketing'),('research'),('excel') on conflict do nothing;
insert into public.platform_settings(key,value) values('platform_fee_percent','10'),('referral_percent','5'),('min_withdrawal_etb','1000'),('withdrawal_fee_etb','0'),('revision_limit','2'),('client_escalation_hours','72'),('deposit_min_etb','100'),('ads_daily_limit','5'),('ads_reward_etb','1') on conflict(key) do nothing;

create index if not exists idx_tasks_status on public.tasks(status);create index if not exists idx_tasks_client on public.tasks(client_id);create index if not exists idx_tasks_worker on public.tasks(assigned_worker_id);create index if not exists idx_notifications_user on public.notifications(user_id);create index if not exists idx_ledger_user on public.ledger_entries(user_id);create index if not exists idx_deposits_user on public.deposits(user_id);create index if not exists idx_withdrawals_user on public.withdrawals(user_id);create unique index if not exists one_active_task_per_worker on public.tasks(assigned_worker_id) where status in('assigned','submitted','revision_requested','disputed');

create or replace function public.ensure_user(p_telegram_id text,p_first_name text default '',p_last_name text default '',p_username text default null,p_start_param text default null) returns public.users language plpgsql security definer as $$ declare v_user public.users;v_ref text;v_referrer uuid;begin insert into public.users(telegram_id,first_name,last_name,username) values(p_telegram_id,coalesce(p_first_name,''),coalesce(p_last_name,''),p_username) on conflict(telegram_id) do update set first_name=excluded.first_name,last_name=excluded.last_name,username=excluded.username,updated_at=now() returning * into v_user;insert into public.wallets(user_id) values(v_user.id) on conflict(user_id) do nothing;if p_start_param like 'ref_%' then v_ref:=substring(p_start_param from 5);begin v_referrer:=v_ref::uuid;exception when others then v_referrer:=null;end;if v_referrer is not null and v_referrer<>v_user.id and not exists(select 1 from public.referrals where referred_id=v_user.id) and exists(select 1 from public.users where id=v_referrer) then insert into public.referrals(referrer_id,referred_id) values(v_referrer,v_user.id);end if;end if;return v_user;end;$$;

create or replace function public.dashboard(p_user_id uuid,p_role text default 'worker',p_ad_limit integer default 5) returns json language sql security definer as $$ select json_build_object('wallet',json_build_object('available',coalesce(w.available,0),'reserved',coalesce(w.reserved,0),'earned',coalesce(w.lifetime_earned,0),'spent',coalesce(w.lifetime_spent,0)),'completed',(select count(*) from public.tasks t where (case when p_role='worker' then t.assigned_worker_id=p_user_id else t.client_id=p_user_id end) and t.status='completed'),'referralEarned',coalesce((select sum(rr.amount) from public.referral_rewards rr where rr.referrer_id=p_user_id),0),'ads',json_build_object('completed',(select count(*) from public.ad_rewards ar where ar.user_id=p_user_id and ar.created_at>=current_date),'limit',p_ad_limit)) from public.wallets w where w.user_id=p_user_id;$$;
create or replace function public.available_tasks(p_worker_id uuid) returns setof public.tasks language sql security definer as $$ select * from public.tasks where status='open' and assigned_worker_id is null and deadline_at>now() and not exists(select 1 from public.tasks where assigned_worker_id=p_worker_id and status in('assigned','submitted','revision_requested','disputed')) order by created_at desc;$$;
create or replace function public.my_tasks(p_worker_id uuid) returns setof public.tasks language sql security definer as $$ select * from public.tasks where assigned_worker_id=p_worker_id order by created_at desc;$$;
create or replace function public.my_posts(p_client_id uuid) returns setof public.tasks language sql security definer as $$ select * from public.tasks where client_id=p_client_id order by created_at desc;$$;
create or replace function public.referral_dashboard(p_user_id uuid,p_bot_username text) returns json language sql security definer as $$ select json_build_object('count',(select count(*) from public.referrals where referrer_id=p_user_id),'earned',coalesce((select sum(amount) from public.referral_rewards where referrer_id=p_user_id),0),'link','https://t.me/'||replace(p_bot_username,'@','')||'?start=ref_'||p_user_id::text);$$;
create or replace function public.wallet_summary(p_user_id uuid) returns json language sql security definer as $$ select json_build_object('available',coalesce(w.available,0),'reserved',coalesce(w.reserved,0),'lifetimeEarned',coalesce(w.lifetime_earned,0),'lifetimeSpent',coalesce(w.lifetime_spent,0),'withdrawals',(select coalesce(sum(amount),0) from public.withdrawals where user_id=p_user_id and status='paid'),'pendingWithdrawals',(select coalesce(sum(amount),0) from public.withdrawals where user_id=p_user_id and status='pending')) from public.wallets w where w.user_id=p_user_id;$$;
create or replace function public.my_deposits(p_user_id uuid) returns setof public.deposits language sql security definer as $$ select * from public.deposits where user_id=p_user_id order by created_at desc;$$;
create or replace function public.my_notifications(p_user_id uuid) returns setof public.notifications language sql security definer as $$ select * from public.notifications where user_id=p_user_id order by created_at desc limit 100;$$;
create or replace function public.read_notifications(p_user_id uuid) returns boolean language plpgsql security definer as $$ begin update public.notifications set read_at=now() where user_id=p_user_id and read_at is null;return true;end;$$;

create or replace function public.accept_task(p_user_id uuid,p_task_id uuid) returns public.tasks language plpgsql security definer as $$ declare v_task public.tasks;begin select * into v_task from public.tasks where id=p_task_id for update;if v_task.id is null then raise exception 'Task not found';end if;if v_task.status<>'open' or v_task.assigned_worker_id is not null then raise exception 'Task is no longer available';end if;if exists(select 1 from public.tasks where assigned_worker_id=p_user_id and status in('assigned','submitted','revision_requested','disputed')) then raise exception 'Worker already has an active task';end if;update public.tasks set assigned_worker_id=p_user_id,assigned_at=now(),status='assigned',updated_at=now() where id=p_task_id returning * into v_task;return v_task;end;$$;
create or replace function public.submit_task(p_user_id uuid,p_task_id uuid,p_content text default '') returns public.submissions language plpgsql security definer as $$ declare v_task public.tasks;v_submission public.submissions;begin select * into v_task from public.tasks where id=p_task_id for update;if v_task.id is null then raise exception 'Task not found';end if;if v_task.assigned_worker_id<>p_user_id then raise exception 'Not your task';end if;if v_task.status not in('assigned','revision_requested') then raise exception 'Task cannot be submitted';end if;insert into public.submissions(task_id,worker_id,content) values(p_task_id,p_user_id,coalesce(p_content,'')) on conflict(task_id) do update set worker_id=excluded.worker_id,content=excluded.content,updated_at=now() returning * into v_submission;update public.tasks set status='submitted',submitted_at=now(),updated_at=now() where id=p_task_id;return v_submission;end;$$;
create or replace function public.request_revision(p_user_id uuid,p_task_id uuid,p_reason text) returns public.tasks language plpgsql security definer as $$ declare v_task public.tasks;begin select * into v_task from public.tasks where id=p_task_id for update;if v_task.id is null then raise exception 'Task not found';end if;if v_task.client_id<>p_user_id then raise exception 'Not your task';end if;if v_task.status<>'submitted' then raise exception 'Task is not awaiting revision';end if;if v_task.revision_count>=v_task.revision_limit then raise exception 'Revision limit reached';end if;if trim(coalesce(p_reason,''))='' then raise exception 'Revision reason is required';end if;insert into public.revisions(task_id,client_id,reason) values(p_task_id,p_user_id,p_reason);update public.tasks set revision_count=revision_count+1,status='revision_requested',updated_at=now() where id=p_task_id returning * into v_task;return v_task;end;$$;
create or replace function public.open_dispute(p_user_id uuid,p_task_id uuid,p_reason text,p_evidence text default '') returns public.disputes language plpgsql security definer as $$ declare v_task public.tasks;v_dispute public.disputes;begin select * into v_task from public.tasks where id=p_task_id for update;if v_task.id is null then raise exception 'Task not found';end if;if v_task.client_id<>p_user_id and v_task.assigned_worker_id<>p_user_id then raise exception 'Not authorized';end if;if v_task.status not in('submitted','revision_requested') then raise exception 'Task cannot be disputed';end if;if trim(coalesce(p_reason,''))='' then raise exception 'Dispute reason is required';end if;insert into public.disputes(task_id,opened_by,reason,evidence) values(p_task_id,p_user_id,p_reason,coalesce(p_evidence,'')) returning * into v_dispute;update public.tasks set status='disputed',updated_at=now() where id=p_task_id;return v_dispute;end;$$;

create or replace function public.create_task(p_client_id uuid,p_category text,p_title text,p_description text,p_requirements text,p_budget numeric,p_deadline_at timestamptz) returns public.tasks language plpgsql security definer as $$ declare v_task public.tasks;v_fee numeric;v_reward numeric;begin if trim(coalesce(p_title,''))='' or trim(coalesce(p_description,''))='' then raise exception 'Title and description are required';end if;if p_budget<=0 then raise exception 'Invalid budget';end if;if p_deadline_at<=now() then raise exception 'Deadline must be in the future';end if;v_fee:=round(p_budget*(coalesce((select value::numeric from public.platform_settings where key='platform_fee_percent'),'10')/100),2);v_reward:=round(p_budget-v_fee,2);update public.wallets set available=available-p_budget,reserved=reserved+p_budget,updated_at=now() where user_id=p_client_id and available>=p_budget;if not found then raise exception 'Insufficient balance';end if;insert into public.tasks(client_id,category,title,description,requirements,budget,platform_fee,worker_reward,deadline_at) values(p_client_id,p_category,p_title,p_description,coalesce(p_requirements,''),p_budget,v_fee,v_reward,p_deadline_at) returning * into v_task;return v_task;end;$$;
create or replace function public.approve_task(p_user_id uuid,p_task_id uuid) returns public.tasks language plpgsql security definer as $$ declare v_task public.tasks;v_ref uuid;v_reward numeric;v_fee numeric;v_referral numeric;begin select * into v_task from public.tasks where id=p_task_id for update;if v_task.id is null then raise exception 'Task not found';end if;if v_task.client_id<>p_user_id then raise exception 'Not your task';end if;if v_task.status<>'submitted' then raise exception 'Task is not awaiting approval';end if;v_reward:=v_task.worker_reward;v_fee:=v_task.platform_fee;v_referral:=round(v_reward*(coalesce((select value::numeric from public.platform_settings where key='referral_percent'),'5')/100),2);update public.wallets set reserved=greatest(0,reserved-v_task.budget),updated_at=now() where user_id=v_task.client_id;update public.wallets set available=available+v_reward,lifetime_earned=lifetime_earned+v_reward,updated_at=now() where user_id=v_task.assigned_worker_id;insert into public.ledger_entries(user_id,task_id,type,amount,reference_id,description) values(v_task.assigned_worker_id,p_task_id,'task_earning',v_reward,p_task_id::text,'Task completed');select r.referrer_id into v_ref from public.referrals r where r.referred_id=v_task.assigned_worker_id;if v_ref is not null and v_referral<=v_fee and not exists(select 1 from public.referral_rewards where task_id=p_task_id) then update public.wallets set available=available+v_referral,lifetime_earned=lifetime_earned+v_referral,updated_at=now() where user_id=v_ref;insert into public.referral_rewards(referral_id,task_id,referrer_id,referred_worker_id,amount) select r.id,p_task_id,r.referrer_id,v_task.assigned_worker_id,v_referral from public.referrals r where r.referred_id=v_task.assigned_worker_id;insert into public.ledger_entries(user_id,task_id,type,amount,reference_id,description) values(v_ref,p_task_id,'referral_reward',v_referral,p_task_id::text,'Referral reward');end if;update public.tasks set status='completed',completed_at=now(),updated_at=now() where id=p_task_id returning * into v_task;return v_task;end;$$;

create or replace function public.create_deposit(p_user_id uuid,p_amount numeric,p_method text,p_reference text default null,p_proof_url text default null) returns public.deposits language plpgsql security definer as $$ declare v_deposit public.deposits;begin if p_amount<coalesce((select value::numeric from public.platform_settings where key='deposit_min_etb'),'100') then raise exception 'Minimum deposit is 100 ETB';end if;if trim(coalesce(p_method,''))='' then raise exception 'Payment method is required';end if;insert into public.deposits(user_id,amount,method,reference,proof_url) values(p_user_id,p_amount,p_method,p_reference,p_proof_url) returning * into v_deposit;return v_deposit;end;$$;
create or replace function public.create_withdrawal(p_user_id uuid,p_amount numeric,p_method text,p_account_number text,p_account_name text) returns public.withdrawals language plpgsql security definer as $$ declare v_withdrawal public.withdrawals;begin if p_amount<coalesce((select value::numeric from public.platform_settings where key='min_withdrawal_etb'),'1000') then raise exception 'Minimum withdrawal is 1000 ETB';end if;if trim(coalesce(p_method,''))='' or trim(coalesce(p_account_number,''))='' or trim(coalesce(p_account_name,''))='' then raise exception 'Withdrawal information is required';end if;update public.wallets set available=available-p_amount,reserved=reserved+p_amount,updated_at=now() where user_id=p_user_id and available>=p_amount;if not found then raise exception 'Insufficient balance';end if;insert into public.withdrawals(user_id,amount,method,account_number,account_name) values(p_user_id,p_amount,p_method,p_account_number,p_account_name) returning * into v_withdrawal;return v_withdrawal;end;$$;

create or replace function public.admin_dashboard() returns json language sql security definer as $$ select json_build_object('users',(select count(*) from public.users),'tasks',(select count(*) from public.tasks),'open_tasks',(select count(*) from public.tasks where status='open'),'completed_tasks',(select count(*) from public.tasks where status='completed'),'pending_deposits',(select count(*) from public.deposits where status='pending'),'pending_withdrawals',(select count(*) from public.withdrawals where status='pending'),'disputes',(select count(*) from public.disputes where status='open'));$$;
create or replace function public.admin_deposit(p_deposit_id uuid,p_admin_id uuid,p_approve boolean) returns public.deposits language plpgsql security definer as $$ declare v_deposit public.deposits;begin if not exists(select 1 from public.users where id=p_admin_id and is_admin) then raise exception 'Not authorized';end if;select * into v_deposit from public.deposits where id=p_deposit_id for update;if v_deposit.id is null then raise exception 'Deposit not found';end if;if v_deposit.status<>'pending' then raise exception 'Deposit already processed';end if;if p_approve then update public.wallets set available=available+v_deposit.amount,updated_at=now() where user_id=v_deposit.user_id;update public.deposits set status='approved',reviewed_by=p_admin_id,reviewed_at=now() where id=p_deposit_id;insert into public.ledger_entries(user_id,type,amount,reference_id,description) values(v_deposit.user_id,'deposit',v_deposit.amount,p_deposit_id::text,'Approved deposit');else update public.deposits set status='rejected',reviewed_by=p_admin_id,reviewed_at=now() where id=p_deposit_id;end if;select * into v_deposit from public.deposits where id=p_deposit_id;return v_deposit;end;$$;
create or replace function public.admin_withdraw(p_withdrawal_id uuid,p_admin_id uuid,p_approve boolean) returns public.withdrawals language plpgsql security definer as $$ declare v_withdrawal public.withdrawals;begin if not exists(select 1 from public.users where id=p_admin_id and is_admin) then raise exception 'Not authorized';end if;select * into v_withdrawal from public.withdrawals where id=p_withdrawal_id for update;if v_withdrawal.id is null then raise exception 'Withdrawal not found';end if;if v_withdrawal.status<>'pending' then raise exception 'Withdrawal already processed';end if;if p_approve then update public.wallets set reserved=greatest(0,reserved-v_withdrawal.amount),updated_at=now() where user_id=v_withdrawal.user_id;update public.withdrawals set status='paid',processed_by=p_admin_id,processed_at=now() where id=p_withdrawal_id;insert into public.ledger_entries(user_id,type,amount,reference_id,description) values(v_withdrawal.user_id,'withdrawal',-v_withdrawal.amount,p_withdrawal_id::text,'Paid withdrawal');else update public.wallets set available=available+v_withdrawal.amount,reserved=greatest(0,reserved-v_withdrawal.amount),updated_at=now() where user_id=v_withdrawal.user_id;update public.withdrawals set status='rejected',processed_by=p_admin_id,processed_at=now(),rejection_reason='Rejected by admin' where id=p_withdrawal_id;end if;select * into v_withdrawal from public.withdrawals where id=p_withdrawal_id;return v_withdrawal;end;$$;
create or replace function public.credit_adsgram_reward(p_user_id uuid,p_event_id text,p_amount numeric default 1) returns boolean language plpgsql security definer as $$ declare v_count integer;begin if exists(select 1 from public.ad_rewards where event_id=p_event_id) then return false;end if;select count(*) into v_count from public.ad_rewards where user_id=p_user_id and created_at>=current_date;if v_count>=coalesce((select value::integer from public.platform_settings where key='ads_daily_limit'),'5') then return false;end if;insert into public.ad_rewards(user_id,amount,event_id) values(p_user_id,p_amount,p_event_id);update public.wallets set available=available+p_amount,lifetime_earned=lifetime_earned+p_amount,updated_at=now() where user_id=p_user_id;insert into public.ledger_entries(user_id,type,amount,reference_id,description) values(p_user_id,'ad_reward',p_amount,p_event_id,'AdsGram reward');return true;end;$$;
create or replace function public.expire_open_tasks() returns integer language plpgsql security definer as $$ declare v_count integer;begin update public.tasks set status='expired',updated_at=now() where status='open' and deadline_at<=now();get diagnostics v_count=row_count;return v_count;end;$$;

revoke all on function public.ensure_user(text,text,text,text,text) from public;revoke all on function public.accept_task(uuid,uuid) from public;revoke all on function public.submit_task(uuid,uuid,text) from public;revoke all on function public.approve_task(uuid,uuid) from public;revoke all on function public.create_task(uuid,text,text,text,text,numeric,timestamptz) from public;revoke all on function public.create_deposit(uuid,numeric,text,text,text) from public;revoke all on function public.create_withdrawal(uuid,numeric,text,text,text) from public;

-- ============================================================
-- SERA TIME FINAL HARDENING / CATEGORY SEED
-- Safe to run after the base schema above.
-- ============================================================

insert into public.platform_settings(key,value) values
('platform_fee_percent','10'),('referral_percent','5'),('min_withdrawal_etb','1000'),
('withdrawal_fee_etb','0'),('revision_limit','2'),('client_escalation_hours','72'),
('deposit_min_etb','100'),('ads_daily_limit','5'),('ads_reward_etb','1')
on conflict(key) do nothing;

insert into public.categories(name,active) values
('graphic_design',true),('logo_design',true),('ui_ux',true),('presentation_design',true),('illustration',true),('3d_design',true),
('video_editing',true),('photo_editing',true),('motion_graphics',true),('animation',true),('voice_over',true),('audio_editing',true),
('writing',true),('translation',true),('transcription',true),('proofreading',true),
('data_entry',true),('excel',true),('data_analysis',true),('web_research',true),
('programming',true),('website_development',true),('mobile_app',true),('api_development',true),('wordpress',true),('automation',true),
('ai_services',true),('prompt_engineering',true),('ai_content',true),
('marketing',true),('social_media',true),('seo',true),('lead_generation',true),('virtual_assistant',true),('customer_support',true),
('research',true),('business_plan',true),('accounting',true),('architecture',true),('engineering',true),('education',true),('photography',true),('marketing_strategy',true),('other',true)
on conflict(name) do update set active=true;

-- Keep task creation financially consistent and make the platform fee/referral relationship explicit.
create or replace function public.create_task(p_client_id uuid,p_category text,p_title text,p_description text,p_requirements text,p_budget numeric,p_deadline_at timestamptz) returns public.tasks language plpgsql security definer as $$
declare v_task public.tasks; v_fee numeric; v_reward numeric; v_fee_pct numeric;
begin
  if trim(coalesce(p_title,''))='' or trim(coalesce(p_description,''))='' then raise exception 'Title and description are required'; end if;
  if p_budget<=0 then raise exception 'Invalid budget'; end if;
  if p_budget>10000000 then raise exception 'Budget is too large'; end if;
  if p_deadline_at<=now() then raise exception 'Deadline must be in the future'; end if;
  if not exists(select 1 from public.categories where name=p_category and active=true) then raise exception 'Category is not available'; end if;
  v_fee_pct:=coalesce((select value::numeric from public.platform_settings where key='platform_fee_percent'),'10');
  if v_fee_pct<0 or v_fee_pct>=100 then raise exception 'Invalid platform fee setting'; end if;
  v_fee:=round(p_budget*v_fee_pct/100,2); v_reward:=round(p_budget-v_fee,2);
  update public.wallets set available=available-p_budget,reserved=reserved+p_budget,lifetime_spent=lifetime_spent+p_budget,updated_at=now() where user_id=p_client_id and available>=p_budget;
  if not found then raise exception 'Insufficient balance'; end if;
  insert into public.tasks(client_id,category,title,description,requirements,budget,platform_fee,worker_reward,deadline_at,revision_limit)
  values(p_client_id,p_category,p_title,p_description,coalesce(p_requirements,''),p_budget,v_fee,v_reward,p_deadline_at,coalesce((select value::integer from public.platform_settings where key='revision_limit'),2)) returning * into v_task;
  insert into public.ledger_entries(user_id,task_id,type,amount,reference_id,description) values(p_client_id,v_task.id,'task_reservation',-p_budget,p_client_id::text,'Task budget reserved');
  return v_task;
end; $$;

create or replace function public.approve_task(p_user_id uuid,p_task_id uuid) returns public.tasks language plpgsql security definer as $$
declare v_task public.tasks; v_ref uuid; v_reward numeric; v_fee numeric; v_referral numeric; v_ref_pct numeric;
begin
  select * into v_task from public.tasks where id=p_task_id for update;
  if v_task.id is null then raise exception 'Task not found'; end if;
  if v_task.client_id<>p_user_id then raise exception 'Not your task'; end if;
  if v_task.status<>'submitted' then raise exception 'Task is not awaiting approval'; end if;
  v_reward:=v_task.worker_reward; v_fee:=v_task.platform_fee;
  v_ref_pct:=coalesce((select value::numeric from public.platform_settings where key='referral_percent'),'5');
  v_referral:=round(v_reward*v_ref_pct/100,2);
  select r.referrer_id into v_ref from public.referrals r where r.referred_id=v_task.assigned_worker_id;
  if v_ref is not null and v_referral>v_fee then raise exception 'Referral reward exceeds platform fee'; end if;
  update public.wallets set reserved=greatest(0,reserved-v_task.budget),updated_at=now() where user_id=v_task.client_id;
  update public.wallets set available=available+v_reward,lifetime_earned=lifetime_earned+v_reward,updated_at=now() where user_id=v_task.assigned_worker_id;
  insert into public.ledger_entries(user_id,task_id,type,amount,reference_id,description) values(v_task.assigned_worker_id,p_task_id,'task_earning',v_reward,p_task_id::text,'Task completed');
  insert into public.ledger_entries(user_id,task_id,type,amount,reference_id,description) values(null,p_task_id,'platform_fee',v_fee,p_task_id::text,'Platform fee');
  if v_ref is not null and v_referral>0 and not exists(select 1 from public.referral_rewards where task_id=p_task_id) then
    update public.wallets set available=available+v_referral,lifetime_earned=lifetime_earned+v_referral,updated_at=now() where user_id=v_ref;
    insert into public.referral_rewards(referral_id,task_id,referrer_id,referred_worker_id,amount) select r.id,p_task_id,r.referrer_id,v_task.assigned_worker_id,v_referral from public.referrals r where r.referred_id=v_task.assigned_worker_id;
    insert into public.ledger_entries(user_id,task_id,type,amount,reference_id,description) values(v_ref,p_task_id,'referral_reward',v_referral,p_task_id::text,'Referral reward');
  end if;
  update public.tasks set status='completed',completed_at=now(),updated_at=now() where id=p_task_id returning * into v_task;
  return v_task;
end; $$;

create or replace function public.create_deposit(p_user_id uuid,p_amount numeric,p_method text,p_reference text default null,p_proof_url text default null) returns public.deposits language plpgsql security definer as $$
declare v_deposit public.deposits; v_min numeric;
begin
  v_min:=coalesce((select value::numeric from public.platform_settings where key='deposit_min_etb'),'100');
  if p_amount<v_min then raise exception 'Minimum deposit is 100 ETB'; end if;
  if trim(coalesce(p_method,'')) not in ('telebirr','bank') then raise exception 'Payment method is not supported'; end if;
  if trim(coalesce(p_reference,''))<>'' and exists(select 1 from public.deposits where reference=trim(p_reference) and status in ('pending','approved')) then raise exception 'This payment reference was already submitted'; end if;
  insert into public.deposits(user_id,amount,method,reference,proof_url) values(p_user_id,round(p_amount,2),p_method,nullif(trim(p_reference),''),p_proof_url) returning * into v_deposit;
  return v_deposit;
end; $$;

create or replace function public.create_withdrawal(p_user_id uuid,p_amount numeric,p_method text,p_account_number text,p_account_name text) returns public.withdrawals language plpgsql security definer as $$
declare v_withdrawal public.withdrawals; v_min numeric; v_fee numeric;
begin
  v_min:=coalesce((select value::numeric from public.platform_settings where key='min_withdrawal_etb'),'1000'); v_fee:=coalesce((select value::numeric from public.platform_settings where key='withdrawal_fee_etb'),'0');
  if p_amount<v_min then raise exception 'Minimum withdrawal is 1000 ETB'; end if;
  if p_amount<=0 then raise exception 'Invalid withdrawal amount'; end if;
  if trim(coalesce(p_method,'')) not in ('telebirr','bank') then raise exception 'Withdrawal method is not supported'; end if;
  if trim(coalesce(p_account_number,''))='' or trim(coalesce(p_account_name,''))='' then raise exception 'Withdrawal information is required'; end if;
  if exists(select 1 from public.withdrawals where user_id=p_user_id and status='pending' and amount=p_amount and method=p_method and account_number=trim(p_account_number)) then raise exception 'This withdrawal is already pending'; end if;
  update public.wallets set available=available-p_amount,reserved=reserved+p_amount,updated_at=now() where user_id=p_user_id and available>=p_amount;
  if not found then raise exception 'Insufficient balance'; end if;
  insert into public.withdrawals(user_id,amount,fee,method,account_number,account_name) values(p_user_id,round(p_amount,2),v_fee,p_method,trim(p_account_number),trim(p_account_name)) returning * into v_withdrawal;
  return v_withdrawal;
end; $$;

create or replace function public.credit_adsgram_reward(p_user_id uuid,p_event_id text,p_amount numeric default 1) returns boolean language plpgsql security definer as $$
declare v_count integer; v_reward numeric;
begin
  v_reward:=coalesce((select value::numeric from public.platform_settings where key='ads_reward_etb'),p_amount);
  if exists(select 1 from public.ad_rewards where event_id=p_event_id) then return false; end if;
  select count(*) into v_count from public.ad_rewards where user_id=p_user_id and created_at>=current_date;
  if v_count>=coalesce((select value::integer from public.platform_settings where key='ads_daily_limit'),'5') then return false; end if;
  insert into public.ad_rewards(user_id,amount,event_id) values(p_user_id,v_reward,p_event_id);
  update public.wallets set available=available+v_reward,lifetime_earned=lifetime_earned+v_reward,updated_at=now() where user_id=p_user_id;
  insert into public.ledger_entries(user_id,type,amount,reference_id,description) values(p_user_id,'ad_reward',v_reward,p_event_id,'AdsGram reward');
  return true;
end; $$;

revoke all on function public.approve_task(uuid,uuid) from public;
revoke all on function public.create_task(uuid,text,text,text,text,numeric,timestamptz) from public;
revoke all on function public.create_deposit(uuid,numeric,text,text,text) from public;
revoke all on function public.create_withdrawal(uuid,numeric,text,text,text) from public;
revoke all on function public.credit_adsgram_reward(uuid,text,numeric) from public;


-- Backend-only execution: the Next.js server uses the Supabase service_role.
grant execute on function public.ensure_user(text,text,text,text,text) to service_role;
grant execute on function public.dashboard(uuid,text,integer) to service_role;
grant execute on function public.available_tasks(uuid) to service_role;
grant execute on function public.my_tasks(uuid) to service_role;
grant execute on function public.my_posts(uuid) to service_role;
grant execute on function public.referral_dashboard(uuid,text) to service_role;
grant execute on function public.wallet_summary(uuid) to service_role;
grant execute on function public.my_deposits(uuid) to service_role;
grant execute on function public.my_notifications(uuid) to service_role;
grant execute on function public.read_notifications(uuid) to service_role;
grant execute on function public.accept_task(uuid,uuid) to service_role;
grant execute on function public.submit_task(uuid,uuid,text) to service_role;
grant execute on function public.request_revision(uuid,uuid,text) to service_role;
grant execute on function public.open_dispute(uuid,uuid,text,text) to service_role;
grant execute on function public.approve_task(uuid,uuid) to service_role;
grant execute on function public.create_task(uuid,text,text,text,text,numeric,timestamptz) to service_role;
grant execute on function public.create_deposit(uuid,numeric,text,text,text) to service_role;
grant execute on function public.create_withdrawal(uuid,numeric,text,text,text) to service_role;
grant execute on function public.admin_dashboard() to service_role;
grant execute on function public.admin_deposit(uuid,uuid,boolean) to service_role;
grant execute on function public.admin_withdraw(uuid,uuid,boolean) to service_role;
grant execute on function public.credit_adsgram_reward(uuid,text,numeric) to service_role;
grant execute on function public.expire_open_tasks() to service_role;

-- v7 extras
alter table public.users add column if not exists xp integer not null default 0;
alter table public.users add column if not exists level integer not null default 1;
alter table public.users add column if not exists rating_avg numeric(4,2) not null default 0;
alter table public.users add column if not exists rating_count integer not null default 0;
alter table public.users add column if not exists streak_days integer not null default 0;
alter table public.users add column if not exists last_active_date date;

create table if not exists public.ratings(
  id uuid primary key default gen_random_uuid(),
  task_id uuid not null unique references public.tasks(id) on delete cascade,
  from_user_id uuid not null references public.users(id),
  to_user_id uuid not null references public.users(id),
  score integer not null check(score between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists public.reports(
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.users(id),
  target_user_id uuid references public.users(id),
  task_id uuid references public.tasks(id),
  reason text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

create or replace function public.admin_adjust_balance(
  p_admin_id uuid, p_user_id uuid, p_amount numeric, p_note text default ''
) returns json language plpgsql security definer as $$
begin
  if not exists(select 1 from public.users where id=p_admin_id and is_admin) then
    raise exception 'Not authorized';
  end if;
  update public.wallets set available=available+p_amount, updated_at=now() where user_id=p_user_id;
  insert into public.ledger_entries(user_id,type,amount,description)
  values(p_user_id,'admin_adjust',p_amount,coalesce(p_note,'Admin adjustment'));
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
  values(p_admin_id,'adjust_balance','user',p_user_id::text,jsonb_build_object('amount',p_amount,'note',p_note));
  return json_build_object('ok',true);
end; $$;

create or replace function public.admin_ban_user(
  p_admin_id uuid, p_user_id uuid, p_reason text, p_ban boolean default true
) returns json language plpgsql security definer as $$
begin
  if not exists(select 1 from public.users where id=p_admin_id and is_admin) then
    raise exception 'Not authorized';
  end if;
  update public.users set banned=p_ban, ban_reason=case when p_ban then p_reason else null end, updated_at=now()
  where id=p_user_id;
  if p_ban then
    insert into public.bans(user_id,type,reason,created_by) values(p_user_id,'admin',p_reason,p_admin_id);
  end if;
  return json_build_object('ok',true,banned,p_ban);
end; $$;

grant execute on function public.admin_adjust_balance(uuid,uuid,numeric,text) to service_role;
grant execute on function public.admin_ban_user(uuid,uuid,text,boolean) to service_role;
